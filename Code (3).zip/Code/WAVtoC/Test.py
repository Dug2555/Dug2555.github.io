from playsound import playsound

playsound('test.wav')