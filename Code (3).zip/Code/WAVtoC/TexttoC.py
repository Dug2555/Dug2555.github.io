from cgitb import text
from turtle import delay
import pyttsx3
from playsound import playsound
import sys
import time
import subprocess
from pydub import AudioSegment

words = sys.argv[1:]
print(words)

for val in words:
    print(val)
    engine = pyttsx3.init()
    engine.say(val)
    engine.save_to_file(val, 'w.wav')
    engine.runAndWait()
    
    subprocess.run(['python', 'ShortenWAV.py', 'w.wav', 'new.wav'])
    subprocess.run(['python', 'WAV2C.py', 'new.wav', 'w.h'])

    
  
  