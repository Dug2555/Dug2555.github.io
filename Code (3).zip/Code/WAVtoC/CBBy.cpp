#include "SoundData.h"
#include "XT_DAC_Audio.h"


int main(){
XT_DAC_Audio_Class DacAudio(25,0);
XT_Wav_Class Sound(sample);


DacAudio.FillBuffer();
if(Sound.Playing == false)
    DacAudio.Play(&Sound);
}